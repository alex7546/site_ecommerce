<?php session_start(); ?>

<?php include('components/header.html') ?>

<?php include('components/navbar.php') ?>

<?php include('components/commande.php') ?>

<?php include('components/footer.html') ?>