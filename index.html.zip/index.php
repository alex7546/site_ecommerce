<?php session_start(); ?>

<?php include('components/header.html') ?>

<?php include('components/navbar.php') ?>

<?php include('components/home.php') ?>

<?php include('components/footer.html') ?>